package com.example.myapplication_arthur.ui.cadastrarCliente;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.myapplication_arthur.R;

public class CadastrarClienteFragment extends Fragment {

    private CadastrarClienteViewModel mViewModel;

    public static CadastrarClienteFragment newInstance() {
        return new CadastrarClienteFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cadastrar_cliente, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(CadastrarClienteViewModel.class);
        // TODO: Use the ViewModel
    }

}