package com.example.myapplication_arthur.ui.alugarCarroInicial;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.myapplication_arthur.databinding.FragmentAlugarCarroInicialBinding;

/**
 * A simple {@link Fragment} subclass.
 *
 * create an instance of this fragment.
 */
public class AlugarCarroInicial extends Fragment {

 private FragmentAlugarCarroInicialBinding binding ;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

      binding = FragmentAlugarCarroInicialBinding.inflate(inflater,container, false);
              View root = binding.getRoot();
                      return root;

    }


}