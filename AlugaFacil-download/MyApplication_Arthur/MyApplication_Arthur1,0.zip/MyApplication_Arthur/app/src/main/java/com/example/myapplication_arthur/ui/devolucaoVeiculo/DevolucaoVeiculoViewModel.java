package com.example.myapplication_arthur.ui.devolucaoVeiculo;

import androidx.lifecycle.ViewModel;

public class DevolucaoVeiculoViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}