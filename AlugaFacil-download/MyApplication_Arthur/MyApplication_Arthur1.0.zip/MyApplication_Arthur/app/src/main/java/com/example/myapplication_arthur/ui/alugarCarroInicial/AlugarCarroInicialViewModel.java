package com.example.myapplication_arthur.ui.alugarCarroInicial;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class AlugarCarroInicialViewModel extends AppCompatActivity {

@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_aluar_carro_inicial);




    }
}